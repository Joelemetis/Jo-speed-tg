const CACHE_NAME = 'jo-speed-local-v4.1.7'; // Nouvelle version pour forcer la mise à jour

const urlsToCache = [
  '/',
  '/index.html',
  
  // === LOGOS & BACKGROUNDS ===
  'images/ecran1/background-welcome.jpeg',
  'images/ecran1/logo-jo-speed-img.png',
  'images/ecran2/background-connexion-img.jpeg',
  'images/ecran2/logo-jo-speed-img.png',
  'images/ecran3/background-welcome.jpeg',
  'images/ecran3/logo-jo-speed.png',
  'images/ecran3.5/background-welcome.jpeg',
  'images/ecran3.5/screen-welcome-profile.jpeg',
  'images/logos/icone-app-jo-speed.jpeg',

  // === CARROUSEL ÉCRAN 4 ===
  'images/ecran4/caroussel-img1-ecran4.jpeg',
  'images/ecran4/caroussel-img2-ecran4.jpeg',
  'images/ecran4/caroussel-img3-ecran4.jpeg',
  'images/ecran4/caroussel-img4-ecran4.jpeg',
  'images/ecran4/caroussel-img5-ecran4.jpeg',
  'images/ecran4/caroussel-img6-ecran4.jpeg',
  'images/ecran4/btn-commander-ecran4.jpeg',

  // === FORMULAIRE (ÉCRAN 5) ===
  'images/carousselecran5/caroussel-img1-ecran5.jpeg',
  'images/carousselecran5/caroussel-img2-ecran5.jpeg',
  'images/carousselecran5/caroussel-img3-ecran5.jpeg',
  'images/carousselecran5/caroussel-img4-ecran5.jpeg',
  'images/carousselecran5/caroussel-img5-ecran5.jpeg',
  'images/commandeform/sous-caroussel-entête.jpeg',
  'images/commandeform/nom1-form-img.jpeg',
  'images/commandeform/nom2-form-img.jpeg',
  'images/commandeform/produit1-form-img.jpeg',
  'images/commandeform/produit2-form-img.jpeg',
  'images/commandeform/retrait1-form-img.jpeg',
  'images/commandeform/retrait2-form-img.jpeg',
  'images/commandeform/livraison1-form-img.jpeg',
  'images/commandeform/livraison2-form-img.jpeg',
  'images/commandeform/option1-form-img.jpeg',
  'images/commandeform/option2-form-img.jpeg',
  'images/commandeform/paiement1-form-img.jpeg',
  'images/commandeform/paiement2-form-img.jpeg',
  'images/commandeform/details1-form-img.jpeg',
  'images/commandeform/details2-form-img.jpeg',
  'images/commandeform/point-exclamation-popup.png',
  'images/commandeform/effacer-formulaire-form-img.jpeg',
  'images/commandeform/envoyer-formulaire-form-img.jpeg',
  'images/commandeform/derniere-image-commandform.jpeg',

  // === MENU ===
  'images/menu/entête-logo-jospeed.jpeg',
  'images/menu/a-propos-de-menu.jpeg',
  'images/menu/mes-colis-menu-img.jpeg',
  'images/menu/suivre-colis-menu-img.jpeg',
  'images/menu/mon-compte-menu-img.jpeg',
  'images/menu/faq-menu-img.jpeg',
  'images/menu/réseau-socio-menu-img.jpeg',
  'images/menu/recrutement-menu-img.jpeg',
  'images/menu/musique-menu-img.jpeg',
  'images/menu/demande-assistance-menu-img.jpeg',
  'images/menu/assistance-popup-jospeed.png',
  'images/menu/tableau-compteur-background.png',

  // === ÉCRAN COMMANDES ===
  'images/commandescreen/aucune-commandescreen-img.jpeg',
  'images/commandescreen/passercommander-command-screen.jpeg',
  'images/commandescreen/commande-passée-img.jpeg',
  'images/commandescreen/vider-commande-img.jpeg',

  // === ÉCRAN SUIVI ===
  'images/suivis/aucune-commandescreen-img.jpeg',
  'images/suivis/btn-commander-command-screen.jpeg',
  'images/suivis/commandepasser-index-img.jpeg',
  'images/suivis/button-suivre-whatsapp.jpeg',
  'images/suivis/entête-suiviscreen-img.jpeg',

  // === ÉCRAN À PROPOS ===
  'images/about/about-img1-logo.jpeg',
  'images/about/about-img2.jpeg',
  'images/about/about-img3.jpeg',
  'images/about/about-img4.jpeg',
  'images/about/about-img5.jpeg',
  'images/about/fondateur-jospeed-img.png',

  // === ÉCRAN COMPTE ===
  'images/compte/nom-complet.jpeg',
  'images/compte/numéro-téléphone.jpeg',
  'images/compte/date-image.jpeg',

  // === AUTRES ÉCRANS ===
  'images/faq/entête-faq.jpeg',
  'images/réseaux/réseaux-screen-img.jpeg',
  'images/recrutement/recrutement-img.jpeg',
  'images/musique/music-screen-entête.jpeg',

  // === POP-UPS ===
  'images/popups/se-déconnecter-jospeed-popup.png',
  'images/popups/vider-commande-popup.png',
  'images/popups/commande-envoyée-popup.jpeg',
  'images/popups/envoi-en-cours-commande.png',
  'images/popups/oups-pas-de-connexion.jpeg',
  'images/popups/connexion-réussie-popup.jpeg'
];

// Installation : Mise en cache
self.addEventListener('install', (event) => {
  self.skipWaiting(); 
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.addAll(urlsToCache).catch(err => {
          console.log('Certaines images locales n\'ont pas pu être mises en cache :', err);
        });
      });
    })
  );
});

// Récupération
self.addEventListener('fetch', (event) => {
  // Ne jamais intercepter Telegram et Google Sheets
  if (event.request.url.includes('api.telegram.org') || event.request.url.includes('script.google.com')) {
    return;
  }
  
  // Cache First (Priorité au cache local)
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }
      
      return fetch(event.request)
        .then((networkResponse) => {
          if (
            event.request.method === 'GET' &&
            networkResponse &&
            networkResponse.status === 200 &&
            !event.request.url.includes('api.')
          ) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseClone);
            });
          }
          return networkResponse;
        })
        .catch(() => {
          // Fallback de secours si une image locale manque
          if (event.request.destination === 'image') {
            return new Response(
              `<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120">
                <rect width="100%" height="100%" fill="#ffd203"/>
                <text x="50%" y="50%" text-anchor="middle" dy=".3em"
                  fill="#000080" font-size="16" font-weight="bold" font-family="Arial">
                  Jo Speed
                </text>
              </svg>`,
              { headers: { 'Content-Type': 'image/svg+xml' } }
            );
          }
        });
    })
  );
});

// Activation : Nettoyage des anciens caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});